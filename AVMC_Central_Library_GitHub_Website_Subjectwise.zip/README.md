# AVMC Central Library Website

Static GitHub Pages website for the AVMC Central Library.

## Main pages
- `index.html` — Home, services, e-resources, journal hub, Web OPAC, Old Question Bank and contact.
- `subject-resources.html` — Subject-wise resource gateway for Medical and Allied Health Sciences.

## Assets
- `assets/avmc-header.jpg` — original AVMC/VMRF header image supplied by the Library.
- `assets/vmrf-digital-library-qr.png` — original VMRF Digital Library QR supplied by the Library.
- `assets/old-question-bank-qr.png` — QR generated from the AVMC Old Question Bank Google Drive folder.
- `assets/journals.json` — journal data generated from the supplied 2026 print, SAGE and ProQuest Excel lists.

## Live links configured
- Web OPAC: http://103.21.77.83/
- Old Question Bank: https://drive.google.com/drive/folders/1uyTlKPnJMBU6uJpTT9k2bfUjVMWNf0kx?usp=sharing
- VMRF Digital Library: https://vmrf.refread.com/#/home

## GitHub Pages
Upload all files and the `assets` folder to the repository root. Keep `index.html` and `subject-resources.html` at the top level.
